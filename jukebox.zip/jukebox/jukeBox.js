var song = document.getElementById("song");
var songName = document.getElementsByClassName("songName")[0];
var artistName = document.getElementsByClassName("artistName")[0];


var starboy = new Songs("Starboy.mp3", "The Weeknd", "Starboy", "Starboy", "starboy");
var partyMonster = new Songs("Partymonster.mp3", "The Weeknd", "Party Monster", "Starboy", "starboy");
var dianeYoung = new Songs("Dianeyoung.mp3", "Vampire Weekend", "Diane Young", "Modern Vampires of the City", "modernVampire");

var firstJukeBox = new JukeBox(starboy);
firstJukeBox.addSong(partyMonster);
firstJukeBox.addSong(dianeYoung);

window.addEventListener("load", function(){
	var songIndex = firstJukeBox.currentSongNum;

	firstJukeBox.songNameDisplay(songIndex);
	firstJukeBox.artistNameDisplay(songIndex);

	})

document.addEventListener("keyup", function(){
	if (event.keyCode = 27){

		firstJukeBox.pauseSong();
	}

})

var andrewWK = document.getElementsByClassName("andrewWK")[0];

andrewWK.addEventListener("click", function(){
	firstJukeBox.playSong();

})

var buttons = document.getElementsByClassName("buttons");

for(var i = 0; i < buttons.length; i++){
	buttons[i].addEventListener("click", function(){

	var operator = event.target.id;

	operation(operator);

	});

}

function operation(operator) {
	if(operator === "rewind"){

	firstJukeBox.previousSong();

	}
	
	if(operator === "play"){
		firstJukeBox.playSong();

	}
	
	if(operator === "pause"){

		firstJukeBox.pauseSong();

	}
	
	if(operator === "next"){
	 	
		firstJukeBox.nextSong();

	}

}

var fileUpload = document.getElementById("fileUpload");

fileUpload.addEventListener("change", function(){

var i = fileUpLoad.value;
console.log(i);

})


function Songs (song, artist, songName, album, albumArt){
	this.song = song;
	this.artist = artist;
	this.songName = songName; 
	this.album = album;
	this.albumArt= albumArt;

}


function JukeBox(songPick){

	this.songsList = [];
	this.songsList.push(songPick);

	this.currentSong = this.songsList[0].song;
	this.currentSongNum = 0;

	this.nextSong = nextSong;
	this.pauseSong = pauseSong;
	this.playSong = playSong;
	this.previousSong = previousSong;
	this.songNameDisplay = songNameDisplay;
	this.artistNameDisplay = artistNameDisplay;
	this.albumArtDisplay = albumArtDisplay;
	
	this.addSong = addSong;

	function nextSong(){
		
		if(this.currentSongNum >= (this.songsList.length - 1)){
			this.currentSongNum = 0;

			var nextSongNum = this.currentSongNum;
			var nextSong = this.songsList[nextSongNum].song;

			this.currentSong = nextSong;

			this.playSong();

		}else{
			
			this.currentSongNum += 1 ;
			var nextSongNum = this.currentSongNum;

			var nextSong = this.songsList[nextSongNum].song;
			
			this.currentSong = nextSong;
			this.playSong();
		}
	}
	
	function pauseSong(){
		song.pause();

	}
	
	function playSong(){
		var songToPlay = this.currentSong;
		var songInfo = this.currentSongNum;
		song.setAttribute("src", songToPlay);
	
		this.songNameDisplay(songInfo);
		this.artistNameDisplay(songInfo);
		this.albumArtDisplay(songInfo);
		song.play();

	}

	function previousSong(){
		if(this.currentSongNum <= 0 ){

			this.currentSongNum = (this.songsList.length - 1);
			
			var previousSongNum = this.currentSongNum;
			this.currentSong = this.songsList[previousSongNum].song;
			
			this.playSong();
			
		} else {
			
			this.currentSongNum -= 1;
			
			var previousSongNum = this.currentSongNum;

			var nextSong = this.songsList[previousSongNum].song;
			
			this.currentSong = nextSong;
			this.playSong();

		}

	}

	function addSong(song){
		this.songsList.push(song);

	}

	function songNameDisplay(i){
		var msg = "";
		msg = this.songsList[i].songName;

		songName.innerHTML =  "Song: " + msg;
	}

	function artistNameDisplay(i){
		var msg = "";
		msg = this.songsList[i].artist;

		artistName.innerHTML = "Artist: " + msg;
	}

	function albumArtDisplay(i){
		andrewWK.removeAttribute("class");

		var albumArt = this.songsList[i].albumArt;
		andrewWK.classList.add("andrewWK");
		andrewWK.classList.add(albumArt);

	}

}





